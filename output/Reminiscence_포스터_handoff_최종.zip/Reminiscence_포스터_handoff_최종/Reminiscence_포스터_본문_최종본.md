# Reminiscence

치매 환자를 위한 AI 대화형 스마트 케어 액자

Reminiscence: An AI-Enabled Conversational Smart Care Frame for People Living with Dementia

KW-Reminiscence

# A0 메인 포스터 원고

## 한 줄 소개

Reminiscence는 치매 환자가 익숙한 가족사진을 보며 음성 대화에 참여하고, 식사·복약 루틴과 대화 패턴의 변화를 보호자가 이해할 수 있는 근거로 전달받도록 설계한 AI 대화형 스마트 케어 액자다.

## 연구 배경

보건복지부의 2023년 치매역학조사는 국내 65세 이상 인구의 치매 유병률을 9.25%로 보고했다. 2025년 치매 환자는 약 97만 명, 2026년에는 100만 명을 넘을 것으로 추정되며, 지역사회 치매 환자 가족의 45.8%가 돌봄 부담을 보고했다. 치매는 기억과 사고뿐 아니라 대화와 익숙한 일상 수행에도 영향을 주며, 진행될수록 가족과 보호자의 관찰과 지원에 대한 의존이 커진다.

세계보건기구는 뇌를 자극하고 일상 기능을 유지하는 활동과 사회적 상호작용의 중요성을 제시한다. 가족사진과 같은 친숙한 단서를 이용한 회상 활동은 과거 경험을 이야기하도록 돕는 접근으로 사용되어 왔다. Cochrane 체계적 문헌고찰은 일부 환경에서 삶의 질, 인지, 의사소통과 기분에 작은 이점이 나타날 수 있다고 보고했으나 효과는 중재 방식과 환경에 따라 달랐다. 디지털 회상 활동의 예비 연구도 가능성을 제시했지만 임상 효과를 일반화하기에는 근거가 제한적이다.

필요한 것은 병원 밖의 생활 공간에서 반복적으로 사용할 수 있고, 환자에게 복잡한 조작을 요구하지 않으며, 보호자가 곁에 없을 때에도 대화 참여와 생활 루틴의 변화를 이어서 관찰할 수 있는 매개다. Reminiscence는 치료나 진단을 목표로 삼지 않고, 가족사진 액자의 익숙한 형식에 AI 음성 상호작용과 개인별 변화 관찰을 결합한다.

## 문제 정의

### 지속하기 어려운 회상 대화

회상 활동은 사진을 함께 보고 질문하며 응답을 기다려 줄 사람이 있을 때 이어지기 쉽다. 가족이나 돌봄 인력이 매일 같은 시간에 대화를 제공하기는 어렵고, 환자가 스스로 앱을 찾아 실행하는 방식도 지속성을 떨어뜨릴 수 있다. 생활 공간에 놓인 가족사진 액자가 정해진 시각 또는 사용자가 원하는 때에 음성으로 대화를 제안하고, 말로 응답할 수 있는 상호작용 통로를 제공할 필요가 있다.

### 보호자에게 보이지 않는 생활 변화

함께 거주하지 않는 보호자는 식사와 복약 루틴의 미응답, 대화량 감소와 같은 변화를 연속적으로 확인하기 어렵다. 한 번의 미응답이나 짧은 대화는 일정 변경, 피로, 기기 미사용으로도 발생하므로 곧바로 위험 신호로 해석할 수 없다. 일상에서 부담 없이 축적한 루틴과 대화 지표를 개인의 평소 패턴과 비교하고, 변화가 반복될 때 관찰 근거를 전달하는 연결 장치가 필요하다.

### 기존 디지털 기기의 높은 조작 부담

치매 환자는 긴 문장과 복잡한 메뉴를 이해하거나 여러 단계의 조작을 기억하는 데 어려움을 겪을 수 있다. 돌봄 도구가 별도의 앱 학습과 반복 입력을 요구하면 사용 자체가 중단될 가능성이 커진다. 평상시에는 가족사진만 보여 주고, 필요한 순간에 음성 안내와 큰 기록 버튼을 제시하며, 활동이 끝나면 다시 사진 화면으로 돌아가는 인터페이스가 필요하다.

## 연구 질문과 목표

연구 질문은 치매 환자의 생활 공간에 놓인 가족사진 액자에 AI 음성 대화, 루틴 기록, 개인별 변화 관찰과 설명 가능한 보호자 알림을 통합할 수 있는가이다. 구현 목표는 환자에게 새로운 기기 사용 절차를 요구하지 않으면서 대화와 일상 기록의 접점을 만들고, 보호자가 연속적인 생활 변화를 확인할 수 있는 작동 가능한 프로토타입을 구축하는 것이다.

본 프로젝트에서 AI는 OpenAI API 기반 음성 전사와 후속 질문 생성, Supertonic 3 음성 합성, 개인 이력 기반 Isolation Forest 평가에 사용된다. 대화는 고정형 시작 문구로 진입하고, 이후에는 사용자의 직전 응답과 대화 맥락을 바탕으로 LLM이 회상을 이어 갈 질문을 생성한다. 생성 질문은 사진 속 사실을 단정하거나 사용자의 기억을 교정하지 않는 열린 문장으로 제한하며, 이상 결과는 의료 진단이 아닌 보호자 확인을 위한 관찰 신호로 사용한다.

## 시스템 설계

태블릿 클라이언트는 날짜와 가족사진을 표시하고, 큰 기록 버튼, 마이크와 스피커를 제공한다. Raspberry Pi의 FastAPI 애플리케이션은 루틴 상태 전이, 회상 대화 조정, 음성 전사와 LLM 연동, 지표 축약, Supertonic 3 음성 합성, 로컬 JSON 저장, 이상 평가와 보호자 이메일 조정을 담당한다.

회상 대화의 WAV는 Raspberry Pi 메모리에서 16 kHz mono PCM 16-bit로 정규화된다. 정규화한 음성은 OpenAI API의 POST /v1/audio/transcriptions로 전송되며 모델 식별자는 gpt-4o-transcribe이다. 반환된 text는 대화 지표로 축약되는 동시에 후속 질문 생성을 위한 일시적 대화 맥락으로 사용되고 로컬 파일에는 보존되지 않는다. OpenAI API의 서버 측 데이터 처리는 운영 시 별도로 확인한다.

첫 질문은 “이 사진을 천천히 보시고, 떠오르는 이야기가 있으면 들려주세요”와 같은 고정형 문구로 시작한다. 사용자 응답이 전사되면 LLM은 직전 응답과 현재 세션 맥락에서 회상을 확장할 짧은 후속 질문을 생성한다. 생성된 문구는 Raspberry Pi에서 실행되는 Supertonic 3 ONNX 모델로 합성한다. 음성 출력 설정은 한국어, F1 음색, 0.9배속, 8 inference steps이며 결과는 PCM 16-bit WAV로 반환한다. 합성 WAV는 Cache-Control: no-store로 전달하고 TTS 계층에서 파일이나 장기 캐시로 보존하지 않는다.

![Figure 1. 시스템과 데이터 경계](figures/Figure_01_system_data_boundary.png)

Figure 1. 태블릿, Raspberry Pi, OpenAI API와 SMTP의 데이터 경계. WAV와 대화 text는 전사와 후속 질문 생성에 일시 사용되고 축약 지표만 로컬 JSON에 저장된다.

## 사용자 시나리오

평상시 태블릿은 날짜와 가족사진을 보여 준다. 예정 시각이 되면 화면에 루틴 이름과 큰 기록 버튼을 표시하고 Raspberry Pi가 합성한 안내 음성을 재생한다. 사용자가 응답 가능 시간 안에 버튼을 누르면 해당 수행 건은 CONFIRMED로 종료된다. 입력이 없으면 설정된 유예시간과 재알림 간격에 따라 안내를 반복하고, 응답 기한이 끝나면 NOT_ANSWERED로 마감한 뒤 사진 화면으로 복귀한다.

회상 대화는 설정된 시각의 권유 또는 사용자의 자발적 시작으로 진행된다. 태블릿은 가족사진과 고정형 시작 문구를 제시하고 사용자 음성을 WAV로 전송한다. 서버는 응답을 전사해 지표로 축약하고, LLM이 직전 응답의 인물·장소·감정·경험 단서를 이어 갈 열린 후속 질문을 생성하도록 요청한다. 후속 질문은 Supertonic 3 음성으로 재생되며 같은 흐름을 반복한다. 정시 권유를 지나쳤다는 사실은 저장하거나 이상으로 판정하지 않으며, 같은 날 늦게 시작한 자발적 대화도 정상 참여로 기록한다.

규칙 기반 변화, 개인별 Isolation Forest 결과와 변화의 지속성 가운데 두 신호 이상이 충족되면 개인별 이상을 확정한다. 상태가 NORMAL에서 ANOMALOUS로 전환될 때 보호자에게 현재 관찰 근거를 담은 이메일을 한 번 전송하며, 같은 이상 상태가 지속되는 동안에는 반복 발송하지 않는다.

![Figure 2. 사용자 시나리오](figures/Figure_02_user_scenario.png)

Figure 2. 사진 화면에서 루틴 또는 회상 대화를 수행하고 복귀하는 흐름. 회상 대화는 고정형 시작 문구 뒤 LLM 생성 후속 질문을 반복한다.

## 개인 기준 이상 평가

루틴 행동과 회상 대화는 데이터의 성격과 관측 주기가 달라 별도로 분석한다. 루틴 모델은 식사·복약 미응답률, 확인 지연시간, 전체 완료율과 동일 루틴의 최대 연속 미응답 횟수로 구성한 하루 요약 벡터를 사용한다. 루틴 결과가 존재하는 초기 28일에는 동일 루틴에서 NOT_ANSWERED가 3회 연속 발생하는지를 확인하고, 중간에 CONFIRMED가 발생하면 연속 횟수를 초기화한다. 개인별 루틴 Isolation Forest는 28일 이후 활성화한다.

회상 대화 품질 모델은 한 세션의 사용자 턴 수, 총 글자 수, 평균 글자 수, 평균 턴 입력 시간과 무응답 횟수를 사용하며, 20세션이 축적된 뒤 활성화한다. 한 세션의 이상은 후보로 기록하고 최근 3세션 가운데 2세션 이상이 비정상일 때 지속성 신호로 인정한다. 참여량은 초기 28일의 네 개 7일 구간에서 계산한 평균을 개인 기준으로 삼는다. 최근 7일 사용자 턴 수가 기준보다 50% 이상이면서 10턴 이상 감소한 상태가 2일 연속 유지될 때 참여량 이상 신호로 인정한다.

최종 판단에는 규칙 기반 신호, Isolation Forest 신호와 지속성 신호를 사용한다. 세 신호 가운데 두 신호 이상이 충족되면 이상으로 확정한다. 콜드 스타트 구간에서는 Isolation Forest 대신 명시적인 연속 미응답 규칙과 지속 조건을 조합한다. 루틴과 회상 대화 가운데 한 영역만 이상이어도 알림 후보가 되며, 두 영역이 같은 기간에 함께 변하면 하나의 종합 근거로 설명한다.

Isolation Forest 점수는 건강 위험의 확률이나 중증도가 아니다. 보호자에게는 점수보다 최근 7일 대화 턴 수 감소, 글자 수 감소, 무응답 증가, 루틴 미응답 비율 증가와 같은 관찰 근거를 전달한다.

## 구현 검증

현재 저장소의 자동 검증은 pytest 274건 통과와 선택형 Supertonic 실모델 smoke test 1건 제외, Ruff 정적 검사 통과, mypy 44개 source files 오류 없음으로 확인되었다. 이 검증 범위에는 LLM 후속 질문 생성이 포함되지 않는다. 외부 OpenAI API, 실제 Supertonic model weights와 SMTP 연결도 기본 테스트에서 test double로 대체되므로 이 결과는 질문의 적절성이나 외부 서비스 성능을 의미하지 않는다.

대화 이상 평가의 재현 예시는 handoff용 합성 fixture를 사용했다. 20개 기준 세션은 요일 변화와 완만한 감소를 포함하며 사용자 턴 3–7회, 총 53–158자, 평균 입력 시간 6.7–9.4초, 무응답 0–1회 범위로 구성했다. 21번째 세션은 사용자 턴 2회, 총 31자, 평균 입력 시간 5.4초, 무응답 2회로 구성했다. 대화 품질 모델은 21번째 세션을 이상 후보로 판정했다. 한 세션의 결과만으로 최종 이상이나 보호자 알림을 확정하지 않으며, 이 예시는 합성 입력에 대한 모델 동작을 보여 주는 자료다.

## 한계

현재 검증에는 실제 고령 사용자 연구, 임상 결과, 한국어 전사 WER·CER, 실제 Raspberry Pi 음성 처리 지연과 Supertonic 3 합성 지연·RTF·메모리 측정, 이상 탐지 precision·recall·false alarm rate가 없다. LLM 후속 질문은 사용자 응답을 잘못 해석하거나 부적절한 회상 단서를 제시할 수 있으므로 고령 사용자 대상 질문 적절성 평가가 필요하다. 음성과 일시적 대화 맥락은 OpenAI API로 전송되므로 완전한 장치 내 음성 처리로 표현할 수 없다. 28일, 20세션, 50%, 10턴과 같은 기준은 기획 단계의 정책값이며 사용자 자료로 타당성을 검증하지 않았다. 보호자 이메일은 이상 에피소드당 한 번만 시도하며 실패 재시도, 수신 확인과 과거 알림 이력을 제공하지 않는다.

## 논의 및 결론

Reminiscence는 가족사진을 보여 주는 익숙한 액자 화면에 AI 회상 대화, 식사·복약 루틴 기록, 개인별 변화 평가와 보호자 알림을 통합해 구현했다. 고정형 시작 문구는 대화 진입점을 일정하게 제공하고, LLM 후속 질문과 Supertonic 3 음성 출력은 사용자의 응답에 맞춰 회상 대화를 이어 간다. 큰 기록 버튼과 활동 후 사진 화면 복귀는 일상적인 사용 흐름을 유지한다.

루틴과 회상 대화를 별도로 분석하고 규칙 기반 신호, Isolation Forest와 지속성 조건을 결합해 일시적인 변화를 걸러 낸다. 보호자에게는 모델 점수 대신 미응답, 대화량 감소와 같은 관찰 근거를 전달하며, 원본 음성과 대화 원문은 장기 저장하지 않는다. 구현 결과는 회상 활동과 생활 기록을 한 장치에서 연결하고 개인의 평소 패턴 변화를 설명 가능한 형태로 전달할 수 있음을 보여 준다. 실제 대화 지속성, 사용성, 보호자 관찰 지원 효과와 장기 이상 탐지 성능은 고령 사용자 연구와 장기 운영 자료를 통해 평가할 필요가 있다.

# A1 기술 및 시연 포스터 원고

## 음성 전사 경계

대화 턴 endpoint는 audio/wav와 audio/x-wav만 허용하고 요청 크기를 10 MiB로 제한한다. 존재하지 않거나 완료된 세션과 허용 크기를 초과한 요청은 외부 전사 호출 전에 거부한다. 유효한 WAV는 파일을 만들지 않고 메모리에서 16 kHz mono PCM 16-bit로 정규화한다.

OpenAI API 요청은 /v1/audio/transcriptions에 multipart 형식으로 전송한다. 필드는 speech.wav 파일, gpt-4o-transcribe 모델 식별자와 한국어 회상 대화를 알리는 고정 prompt로 제한한다. 기본 timeout은 연결 10초와 응답 150초이며 redirect와 retry를 사용하지 않는다.

정상 응답의 text는 공백을 제외한 글자 수와 무응답 여부로 즉시 축약한다. 입력 시간은 태블릿이 측정해 전달한 0초 이상 300초 이하의 턴 시간이다. 저장 항목은 글자 수, 입력 시간, 초당 글자 수, 무응답 여부, ASR latency와 시도 횟수이며 WAV, 전사문과 provider 원문 응답은 Reminiscence 로컬 저장소에 남기지 않는다.

## 회상 질문 생성

세션을 시작할 때에는 사진을 천천히 보고 떠오르는 이야기를 말해 달라는 고정형 문구를 사용한다. 첫 응답부터는 전사 text와 세션의 최근 대화 맥락을 OpenAI API 기반 LLM에 전달해 인물, 장소, 감정이나 경험을 더 이야기할 수 있는 짧은 후속 질문을 생성한다. 질문 정책은 사진 속 사실을 추정하지 않고, 기억의 오류를 지적하거나 정답을 요구하지 않으며, 의료적 해석과 불안을 유발하는 표현을 제외하도록 구성한다.

생성된 문구는 화면 표시와 Supertonic 3 합성에 함께 사용한다. 데이터 처리 정책은 전사 text, LLM 입력 맥락과 생성 응답을 턴 처리 중에만 사용하고, 활동 기록에는 글자 수, 응답 시간과 무응답 여부 같은 축약 지표만 남기는 방식으로 설계한다.

## Supertonic 3 로컬 음성 출력

Raspberry Pi는 Supertonic 3의 공식 Python SDK와 ONNX Runtime을 이용해 질문과 루틴 안내를 합성한다. 프로세스는 모델과 F1 voice style을 한 번 로딩하고 합성 호출을 직렬화한다. 기본 설정은 language ko, speed 0.9, total steps 8, 최대 500자이다. 출력 waveform은 메모리에서 PCM 16-bit WAV로 인코딩하고, 엔진 sample rate와 waveform 길이로 계산한 음성 길이를 응답 header에 기록한다.

이 구조는 합성 시 외부 TTS API를 호출하지 않는다. 첫 설치나 배포 준비 단계에는 model assets가 필요하며, 실제 Raspberry Pi에서의 합성 지연과 실시간성은 별도 측정 항목으로 남아 있다.

## 루틴 상태 전이

각 루틴 실행은 예정 시각에 REMINDING으로 시작한다. 응답 가능 시간 안에 버튼이 입력되면 CONFIRMED로 전환하고 확인 시각과 예정 시각의 차이를 기록한다. 응답 기한 이후 입력은 상태를 바꾸지 않고 거부한다.

시연 설정에서 09:00 최초 안내 뒤 10분 유예를 두고 09:10, 09:20, 09:30에 세 번 재알림한다. 09:40까지 입력이 없으면 NOT_ANSWERED로 마감한다. 최초 안내는 최대 재알림 횟수에 포함되지 않으며, 확인 가능 구간은 09:00 이상 09:40 미만이다.

![Figure 3. 루틴 상태 타임라인](figures/Figure_03_routine_timeline.png)

Figure 3. 09:00–09:40 시연 타임라인. 구간 내 버튼 입력은 CONFIRMED, 기한 도달은 NOT_ANSWERED로 종료된다.

## 이상 탐지 구조

루틴 초기 28일에는 동일 루틴의 NOT_ANSWERED 3회 연속 여부를 확인하고, 28일 이후에는 식사·복약 미응답률, 확인 지연시간, 전체 완료율과 최대 연속 미응답 횟수로 구성한 하루 벡터를 개인별 Isolation Forest에 입력한다. 대화 품질 모델은 완료된 20세션 뒤 세션별 턴 수, 글자 수, 입력 시간과 무응답 횟수를 평가한다. 대화 참여량은 최근 7일 사용자 턴 수를 초기 개인 기준과 비교한다.

규칙 기반 신호, Isolation Forest 신호와 지속성 신호 가운데 두 신호 이상이 충족되면 개인별 이상으로 확정한다. 대화 품질은 최근 3세션 중 2세션 이상이 비정상일 때 지속성 신호를 인정한다. 참여량 감소는 개인 기준보다 50% 이상이면서 10턴 이상 감소한 상태가 2일 연속 유지될 때 신호로 반영한다. NORMAL에서 ANOMALOUS로 전환되는 시점에 관찰 근거를 담은 보호자 이메일을 한 번 전송한다.

## 합성 입력 재현 결과

Figure 4는 20개 기준 세션과 21번째 현재 세션을 동일한 feature 계산에 입력한 합성 재현이다. 현재 벡터는 사용자 턴 2회, 총 31자, 평균 15.5자, 평균 턴 입력 5.4초, 무응답 2회이며 plot은 다섯 feature 중 세 개를 표시한다. 대화 품질 모델은 현재 세션을 이상 후보로 판정하고 decision function -0.048242를 반환했다. 이 결과는 한 세션의 모델 후보이며 최근 3세션의 지속성 신호와 세 신호 결합에 따른 최종 이상 확정을 보여 주지 않는다.

![Figure 4. 합성 입력에 대한 이상 탐지 동작](figures/Figure_04_synthetic_anomaly_replay.png)

Figure 4. 20개 기준 세션과 1개 현재 세션의 합성 대화 품질 모델 동작. 현재 세션은 이상 후보이며 최종 이상 확정이나 사용자·임상 자료 기반 성능 평가가 아니다.

## 데이터 보존 경계

| 데이터 | 처리 경로 | Reminiscence 로컬 보존 |
| --- | --- | --- |
| 사용자 WAV | 태블릿, Raspberry Pi 메모리, OpenAI API | 보존하지 않음 |
| 전사 text와 API 응답 | OpenAI API에서 Raspberry Pi 메모리 | 보존하지 않음 |
| 후속 질문용 대화 맥락과 생성 text | Raspberry Pi 메모리, OpenAI API | 보존하지 않음 |
| 대화 턴 지표 | Raspberry Pi metric reducer | activity_metrics.json |
| 루틴 상태와 확인 지연 | Raspberry Pi state machine | activity_metrics.json |
| 설정된 사진 URL과 루틴 | 로컬 구성 파일 | configuration.json |
| 최신 이상 상태와 근거 | Raspberry Pi anomaly service | personal_state.json |
| 합성 요청 text와 WAV | Raspberry Pi Supertonic 3, 태블릿 | TTS 계층에서 보존하지 않음 |
| 알림 시도 표식 | Raspberry Pi notification coordinator | notification_state.json |
| 이메일 본문 | Raspberry Pi, SMTP, 보호자 | 발송 이력으로 보존하지 않음 |
| 운영 자격증명·보호자 연락처 | 별도 secret·환경변수 | application JSON과 분리 |

OpenAI API의 서버 측 데이터 처리는 이 저장소의 로컬 비보존 정책과 별도로 확인해야 한다.

## 기술 구성

| 구성 | 적용·설계 |
| --- | --- |
| 사용자 단말 | 태블릿 클라이언트, 화면·마이크·스피커·WAV 재생 |
| 엣지 서버 | Raspberry Pi, Python 3.12, FastAPI, ASGI |
| 전사 | OpenAI API, gpt-4o-transcribe |
| 후속 질문 | 첫 문구는 고정형, 이후 문구는 OpenAI API 기반 LLM 생성 |
| 음성 출력 | Supertonic 3, 한국어, F1, speed 0.9, 8 steps |
| 로컬 저장 | 프로세스 내 경로 잠금·임시 파일 fsync·원자적 os.replace |
| 이상 평가 | 규칙 기반·Isolation Forest·지속성 신호 중 두 신호 이상 충족 시 확정 |
| 알림 | SMTP STARTTLS, 이상 에피소드당 최대 한 번의 시도 |

## 소프트웨어 검증 결과

| 검사 | 확인 결과 | 해석 범위 |
| --- | --- | --- |
| pytest | 274 passed, 1 skipped, 1 warning | 저장소 전체 단위·통합 테스트와 test double 기반 계약 검증 |
| Ruff | 전체 검사 통과 | 현재 Python source의 lint 검사 |
| mypy | 44 source files 오류 없음 | 현재 type annotation의 정적 검사 |
| OpenAPI | 12 paths, 13 operations | 구현된 API surface 확인 |
| 합성 anomaly replay | 대화 품질 후보 ANOMALOUS, decision function -0.048242 | 20개 기준 세션과 현재 세션의 모델 동작 예시 |

제외된 한 건은 실제 Supertonic 3 model weights를 요구하는 선택형 smoke test이다. LLM 후속 질문 생성, 외부 OpenAI API live test, 한국어 WER·CER, 실제 SMTP 도달, 사용자 연구와 임상 평가는 이 결과에 포함되지 않는다.

## 시연 구성

시연에서는 가족사진 기본 화면, 고정형 시작 문구, 사용자 응답을 반영한 LLM 후속 질문과 Supertonic 3 음성 재생, 09:00 루틴의 기록 버튼과 재알림, WAV 전사 뒤 숫자 지표만 남는 JSON, 합성 이상 입력의 상태 전이와 보호자 이메일을 보여 준다. A1에는 실제 FastAPI OpenAPI 화면 캡처와 저장소 QR을 배치하며, 프런트엔드나 실물 장치의 실제 캡처가 확보되면 API 화면 옆에 교체 또는 추가한다. 생성한 UI 시안을 실제 구현 화면으로 표기하지 않는다.

## 학술적 주장 범위

이 포스터는 시스템 설계와 구현 검증을 보고한다. 회상 대화가 치매를 예방하거나 치료한다는 주장, 개인별 이상 점수가 건강 위험을 예측한다는 주장, 자동 알림이 보호자의 대응 시간을 줄인다는 주장은 현재 자료로 평가하지 않았다. 후속 연구에서는 고령 사용자의 과업 성공률과 이해도, 실제 Raspberry Pi 음성 처리 지연, 한국어 전사 품질, 장기 이상 탐지의 오탐·미탐과 보호자 알림 부담을 측정할 필요가 있다.

# Figure 캡션 원고

## Figure 1

태블릿, Raspberry Pi, OpenAI API와 SMTP의 데이터 경계. WAV와 대화 text는 전사와 후속 질문 생성에 일시 사용되고 축약된 대화·루틴 지표만 로컬 JSON에 저장된다.

## Figure 2

가족사진 화면에서 루틴 또는 회상 대화를 수행하고 복귀하는 사용자 흐름. 회상 대화는 고정형 시작 문구 뒤 사용자의 응답을 반영한 LLM 생성 후속 질문을 반복한다.

## Figure 3

09:00 시작, 10분 간격, 재알림 3회의 시연 설정. 구간 내 버튼 입력은 CONFIRMED, 09:40 도달은 NOT_ANSWERED로 종료된다.

## Figure 4

20개 기준 세션과 21번째 현재 세션의 합성 대화 품질 모델 동작 예시. 현재 세션은 이상 후보이며 최근 3세션의 지속성 신호와 최종 이상 확정은 포함하지 않는다. 사용자·임상 자료와 성능 평가가 아니다.

# 참고문헌

Ministry of Health and Welfare, Republic of Korea. (2025). 2023년 치매역학조사 및 실태조사 결과 발표. https://www.mohw.go.kr/board.es?act=view&bid=0027&list_no=1484959&mid=a10503010300

World Health Organization. (2025). Dementia. https://www.who.int/news-room/fact-sheets/detail/dementia

National Institute on Aging. (2023). Caring for Older Patients With Cognitive Impairment. https://www.nia.nih.gov/health/health-care-professionals-information/caring-older-patients-cognitive-impairment

Woods, B., O’Philbin, L., Farrell, E. M., Spector, A. E., and Orrell, M. (2018). Reminiscence therapy for dementia. Cochrane Database of Systematic Reviews, 2018(3), CD001120. https://doi.org/10.1002/14651858.CD001120.pub3

Moon, S. H., and Park, K. (2020). The effect of digital reminiscence therapy on people with dementia: a pilot randomized controlled trial. BMC Geriatrics, 20, 166. https://doi.org/10.1186/s12877-020-01563-2

Liu, F. T., Ting, K. M., and Zhou, Z.-H. (2008). Isolation Forest. 2008 Eighth IEEE International Conference on Data Mining, 413–422. https://doi.org/10.1109/ICDM.2008.17

World Wide Web Consortium Web Accessibility Initiative. (2025). Older Users and Web Accessibility: Meeting the Needs of Ageing Web Users. https://www.w3.org/WAI/older-users/

OpenAI. (2026). GPT-4o Transcribe Model and Audio API Reference. https://developers.openai.com/api/docs/models/gpt-4o-transcribe

Supertone Inc. (2026). Supertonic 3: On-device multilingual text-to-speech with ONNX Runtime. https://github.com/supertone-inc/supertonic
