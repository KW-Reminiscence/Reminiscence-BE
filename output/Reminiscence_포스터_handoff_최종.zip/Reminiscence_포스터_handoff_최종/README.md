# Reminiscence 포스터 handoff

이 패키지는 학회형 A0 메인 포스터와 A1 기술·시연 포스터를 편집할 때 사용할 최종 원고, 정적 figure, 표 원본, 합성 데이터와 생성 source를 함께 제공한다. 본문은 Markdown과 DOCX 두 형식이며 DOCX에는 figure와 표를 배치해 편집자가 전체 맥락을 확인할 수 있도록 했다.

preview의 PDF는 DOCX를 검수용으로 렌더링한 결과다. MANIFEST.sha256은 압축 시점의 패키지 파일 해시를 기록하며 manifest 자체는 해시 대상에서 제외한다.

## 출력 배치

120×240 cm 백스크린의 상단에서 약 8 cm 아래에 A0 가로형을 배치하면 폭 118.9 cm가 스크린 폭 120 cm 안에 들어간다. A0 아래에 약 5 cm의 간격을 두고 A1 가로형을 가운데 정렬하면 두 장의 하단은 상단 기준 약 157 cm에 위치한다. 테이블 높이 74 cm로 인해 가려지는 하단 영역이 상단 기준 약 166 cm부터 시작하므로 두 포스터의 본문과 figure가 테이블 위에 남는다.

A0에는 프로젝트 소개, 연구 배경과 세 문제, 시스템 경계도, 사용자 시나리오, 개인 기준 평가, 구현 검증, 논의와 한계를 배치한다. Figure 1과 Figure 2를 중앙의 넓은 시각 영역으로 사용하면 원거리에서 장치 역할과 데이터 흐름을 먼저 읽을 수 있다.

A1에는 codex-lb 기반 gpt-4o-transcribe 전사 경계, Supertonic 3 로컬 음성 출력, 루틴 타임라인, 합성 이상 탐지 plot, 데이터 보존 정책, 소프트웨어 검증과 실제 시연 화면을 배치한다. Figure 3과 Figure 4는 기술 설명과 인접하게 두고, 표는 exact lookup이 필요한 하단 또는 우측 영역에 배치한다.

## figure 사용

각 figure는 편집 가능한 SVG와 3200 px 폭의 PNG로 제공한다. PNG는 PowerPoint와 일반 편집 도구에 바로 삽입할 수 있고 SVG는 글자와 색, 간격을 수정할 때 사용한다. Figure 4의 합성 자료 표시는 제목, plot 내부 주석과 캡션에서 유지해야 한다.

실제 사용자 UI와 실물 장치 사진은 현재 백엔드 저장소에 없다. assets의 FastAPI 화면은 실제 실행 화면이며, repository QR은 저장소 연결용이다. 프런트엔드 캡처나 실물 사진을 추가할 때에는 생성 시안과 실제 구현 화면을 구분해야 한다.

## 학술적 표기

ETRI는 현재 runtime 전사 경로가 아니므로 본문과 시스템 도표에서 제외했다. runtime은 codex-lb의 OpenAI 호환 /v1/audio/transcriptions를 사용하며 모델 식별자는 gpt-4o-transcribe이다. WAV와 전사문은 Reminiscence 로컬 저장소에 보존하지 않지만 음성은 전사를 위해 codex-lb로 전송된다. provider 측 보존 정책은 별도 운영 검토 대상이다.

합성 이상 탐지 plot은 저장소의 test fixture를 재현한 동작 예시이다. score는 위험 확률이 아니며 accuracy, sensitivity, specificity 또는 임상적 위험도로 표현할 수 없다. 회상요법 문헌은 설계 배경이며 이 프로토타입의 치매 예방·치료 효과를 입증하지 않는다.

## 편집 전 확인

최종 포스터에는 소속, 참여자 이름, 연락처와 실제 시연 QR의 목적지를 확정해야 한다. 인쇄 직전에는 실제 배치 크기에서 본문 글자, figure 축과 캡션을 확인하고 A0와 A1의 PDF를 100% 크기로 검수한다.
